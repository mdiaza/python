

######### SESION 1 -28-08-2017 ###########

install.packages("planor")
library(planor)

Design<-data.frame(block=rep(1,15),treatment=rep(c(rep("A",5),rep("B",5),rep("C",5)),1))
planor.randomize(~block/UNITS,data=Design)
                  

# block treatment
# 1      1         A
# 2      1         C
# 3      1         C
# 4      1         B
# 5      1         C
# 6      1         B
# 7      1         A
# 8      1         A
# 9      1         C
# 10     1         C
# 11     1         B
# 12     1         A
# 13     1         A
# 14     1         B
# 15     1         B