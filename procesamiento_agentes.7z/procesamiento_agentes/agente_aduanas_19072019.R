
#----------------------------------------------------------------------#
#                   MODELO DE SCORE - AGENTES DE ADUANAS               #
#----------------------------------------------------------------------#
"
Paso 1 --->
Configuraciones previas
Modificar plataforma de 32 bits
Tools-Global Options-modificar a 32 bits y reabrir el programa R
"

#----------------------------------------------------------------------#
#               EXTRACCI�N DE DATOS - ADUANAS + TRIBUTOS               #
#----------------------------------------------------------------------#


# Instalaci�n de librer�as
# install.packages("RODBC")
# install.packages("sqldf")
# install.packages("dplyr")
# install.packages("bindrcpp")



#En caso no poder realizar la instalaci�n, se fuerza la ejecuci�n mediante el siguiente script
trace(utils:::unpackPkgZip, quote(Sys.sleep(2)), at = which(grepl("Sys.sleep", body(utils:::unpackPkgZip), fixed = TRUE)))
#install.packages("psy")


# Invocando Librer�as
library(stringr)
library(RODBC)
library (sqldf)
library(dplyr)
library(bindrcpp)
library(openxlsx)


#---------------------------------------------------------------------#
#                  CONECCIONES A INSTANCIAS                           #
#---------------------------------------------------------------------#

# Conexi�n con la Instancia PRAD1
prad1<-odbcConnect("AD0001", uid="gosorio", pwd="gosorio", believeNRows=FALSE)
odbcGetInfo(prad1)

# Conexi�n con la Instancia BDA_MODBAS
bda<-odbcConnect("BDA_MODBAS", uid="qk32", pwd="clave10", believeNRows=FALSE)
odbcGetInfo(bda)

# Conexi�n al servidor BDU
bdu<-odbcConnect("bdu", uid="bdunqk32", pwd="clave87", believeNRows=FALSE)
odbcGetInfo(bdu)

# Conexi�n con la Instancia BDA_FECNAT
bda2<-odbcConnect("BDA_FTENAC", uid="qk32", pwd="clave10", believeNRows=FALSE)
odbcGetInfo(bda2)




#---------------------------------------------------------------------#
#                EXTRACCI�N DE DATOS DEL PRAD1 - AGENTES              #
#---------------------------------------------------------------------#

#Establecimiento del Directorio de Trabajo
setwd("D:/Usuarios/mdiaza/Desktop/RETO - AGENTES DE ADUANAS/procesamiento_agentes")


#Datos de Agente de Aduanas (Habilitados,Suspendidos, Cancelados)
agentes<- sqlQuery(prad1, "select distinct cagente,cdocumento, 
                           case when cestado ='00' then 'HABILITADO' 
                           When cestado ='01' then 'SUPENDIDO'
                           When cestado ='03' then 'CANCELADO' end ESTADO_AGENTE
                          from directo where tagente='A' and cestado IN ('00','01','03') and tdocumento='4'  and cdocumento<>' '")


#visualizar los datos
agentes$CAGENTE<-str_pad(agentes$CAGENTE, 4, pad = "0")
head(agentes)

#Formato para busqueda 
rucs<-paste(agentes$CDOCUMENTO, collapse="', '")
head(rucs,2)

##----------------------------------------------------------------------------------------##

#Separando Agentes Habilitados y  (Cancelados o Supendidos)
tab_ruc_habilitados<-subset(agentes,agentes$ESTADO_AGENTE=='HABILITADO')
head(tab_ruc_habilitados)

#length(unique(tab_ruc_habilitados$CDOCUMENTO))

tab_ruc_nohabilitados<-subset(agentes,agentes$ESTADO_AGENTE!='HABILITADO')
head(tab_ruc_nohabilitados)

ruc_habilitados<-paste(tab_ruc_habilitados$CDOCUMENTO, collapse="', '")
ruc_nohabilitados<-paste(tab_ruc_nohabilitados$CDOCUMENTO, collapse="', '")




#--------------------------------------------------------------------------------#
#    EXTRAYENDO DATOS DE SOCIOS, REPRESENTALES LEGALES TRIB Y ADUANEROS          #
#--------------------------------------------------------------------------------#


#-- Extrayendo datos de los socios agente de aduanas
SQL<- paste0("SELECT  distinct c.n_dcto_declado,
             num_docsoc 
             FROM     informix.t2991socio a
             inner join informix.vw_cab_unicas  b  on (a.num_nabono=b.nabono AND  a.cod_formul=b.formulario AND  a.num_orden=b.nro_orden)
             inner join informix.identificados c on (b.cic= c.cic)
             where c.n_dcto_declado in ('",rucs,"')
             AND  b.tributo='030801' and cod_tipdocsoc='1'")
socios<- sqlQuery(bdu, SQL)
socios$num_docsoc=as.factor(socios$num_docsoc)
head(socios)


#-- Extrayendo datos de los representantes legales Tributos
SQL1<- paste0("Select distinct rso_numruc, rso_nrodoc from informix.vw_rso
              where len(rso_nrodoc)=8 and rso_numruc IN ('",rucs,"')")
rlegal_tributos<- sqlQuery(bdu, SQL1)
head(rlegal_tributos)


#-- Extrayendo datos de los representantes legales Aduanas de Agentes 
SQL<- paste0("select distinct cdocumento,nume_docum from rep_legal a
              inner join (select distinct cdocumento,cagente from directo where tagente='A' and tdocumento='4' and cestado in ('00','01','03')) b 
              on a.cod_operador=b.cagente 
              where tip_operador='A' and trim(nume_docum)<>' '")
rlegal_aduanas<- sqlQuery(prad1, SQL)
head(rlegal_aduanas)



#-- Consolidadados de representantes legales de agentes aduaneros (tributos+aduanas+ socios) 
matriz_representantes<- sqldf("select * from (select n_dcto_declado as ruc ,num_docsoc as doc_repre 
                              from socios union select * from rlegal_tributos union select * from rlegal_aduanas)
                              where LENGTH(doc_repre)=8  
                              and  ruc in (select cdocumento from agentes )")

matriz_representantes$doc_repre <-str_pad(matriz_representantes$doc_repre , 8, pad = "0")
head(matriz_representantes)






#--------------------------------------------------------------------------------#
#        EXTRACCI�N DE DATOS DE BDAMODBAS (N�MERO TRABAJADORES Y MONTOS)         #
#--------------------------------------------------------------------------------#


#Extracci�n de datos de trabajadores (cantidades m�ximas en el periodo 2018 y montos)
SQL6<- paste0(" select num_docidenti,max(to_number(quinta_cat))quinta_cat,max(to_number(cuarta_cat))cuarta_cat,max(to_number(pensionistas))pensionistas,
              max(to_number(practicantes))practicantes,max(to_number(prest_terceros))prest_terceros,sum(to_number(monto_4ta))monto_4ta,
              sum(to_number(monto_5ta))monto_5ta
              from (Select distinct a.cod_cic,num_docidenti,num_periodo,c720 as quinta_cat,c733 as cuarta_cat, c736 as pensionistas,c738 as practicantes,
              c739 as prest_terceros, (c320+C321) as monto_4ta,(c455+C805) as monto_5ta
              from lzamudio.mod_piv_for_0601 a
              inner join (select * from lzamudio.vw_cab_unicas where cod_formul='0601') b 
              on (a.num_nabono=b.num_nabono and a.num_orden=b.num_orden and a.cod_cic=b.cod_cic and trim(a.num_periodo)=trim(b.per_tributo))
              where substr(num_periodo,1,4)='2018' and num_docidenti  in ('",ruc_habilitados,"')) group by num_docidenti")
trabajadores<- sqlQuery(bda, SQL6)
head(trabajadores,8)


#Nota --> en relaci�n a los montos de 4ta y 5ta categor�a se calcula base imponible + monto retenido
write.xlsx(trabajadores, 'trabajadores.xlsx')




#---------------------------------------------------------------------#
#                   EXTRACCI�N DE DATOS DE MIGRACIONES                #
#---------------------------------------------------------------------#

# Migraciones no cumple con el convenio , el pedido se est� realizando por otro conducto de
# solicitudes de requerimientos de informaci�n y se cuenta informaci�n hasta 201805
# hoy por hoy Migraciones ya no brindar� datos hasta finalizar las coordinaciones 
# con la oficina de convenios


#-- Extrayendo datos Auxiliares de despacho
SQL7<- paste0("SELECT  DISTINCT B.cdocumento,NDOCUMEN FROM SGDESPA A
              inner join (select distinct cdocumento,cagente from directo where tagente='A' and tdocumento='4' ) b on a.CENTIDAD=b.cagente
              where tentidad='A' AND '2018' BETWEEN SUBSTR(FEEXPEDI,1,4) AND SUBSTR(FVENCIMI,1,4) and B.cdocumento in ('",ruc_habilitados,"')")
desp_aux<- sqlQuery(prad1, SQL7)
desp_aux$NDOCUMEN<-str_pad(desp_aux$NDOCUMEN, 8, pad = "0")
doclegales_desp_aux<-paste(desp_aux$NDOCUMEN, collapse="', '")
head(doclegales_desp_aux)


#---------------------------------------------------------------------------------------------------------------

# Migraciones de Despachadores y Auxiliares de Despacho
SQL8<- paste0("select * from (
              Select b.nrodoc as doc_dni from lzamudio.tbl_inct_mm_migraciones a
              inner join (Select distinct nropasaporte,  nrodoc from lzamudio.tbl_inct_padron_pasaporte 
              where len(trim(nrodoc))=8 and tipodoc in ('1','DNI')) b on to_char(a.nrodoc)=to_char(b.nropasaporte)
              where tipoviaje='S' AND tipodoc='PAS'
              union all
              Select nrodoc from lzamudio.tbl_inct_mm_migraciones 
              where tipoviaje='S' AND tipodoc='DNI' and len(trim(nrodoc))=8
) where doc_dni in ('",doclegales_desp_aux,"') ")
migra_desp_aux<- sqlQuery(bda, SQL8)
migra_desp_aux$doc_dni<-str_pad(migra_desp_aux$doc_dni, 8, pad = "0")
head(migra_desp_aux)



#---------------------------------------------------------------------------------------------------------------

## Matriz Final de Migraciones
migraciones= sqldf(" select a.*, d.auxiliares,g.nroviajes_desp_aux  from agentes a
                   left join (select cdocumento,count(ndocumen)auxiliares from desp_aux group by cdocumento)d  on a.cdocumento=d.cdocumento   
                   left join
                   (select cdocumento,count(*)nroviajes_desp_aux from 
                   (select a.* from desp_aux a inner join migra_desp_aux b on a.ndocumen=b.doc_dni)
                   group by cdocumento) g on a.cdocumento=g.cdocumento
                   ")
head(migraciones,20)




#---------------------------------------------------------------------#
#                 EXTRACCI�N DEL REGIMEN TRIBUTARIO                   #
#---------------------------------------------------------------------#


SQL7<- paste0("select distinct vfp_numruc as ruc ,REGIMEN,REGIMEN_nro FROM(
              Select vfp_numruc ,vfp_codtri, vfp_fecalt,
              CASE
              when vfp_codtri in ('030301','033101','035101','034101') then 'REGIMEN GENERAL'
              when vfp_codtri in ('031101') then 'REGIMEN ESPECIAL'
              when vfp_codtri like '04%' then 'REGIMEN RUS'
              when vfp_codtri in ('031201') then 'REGIMEN MYPE TRIBUTARIO'
              ELSE NULL END REGIMEN,
              CASE
              when vfp_codtri in ('030301','033101','035101','034101') then 1
              when vfp_codtri in ('031101') then 2
              when vfp_codtri like '04%' then 3
              when vfp_codtri in ('031201') then 4
              ELSE NULL END REGIMEN_nro from informix.vw_vfp)
              WHERE REGIMEN IS NOT NULL AND vfp_numruc IN ('",ruc_habilitados,"')") 
regimen_tributario<- sqlQuery(bdu, SQL7)
head(regimen_tributario,10)

write.xlsx(regimen_tributario, 'regimen_tributario.xlsx')



#---------------------------------------------------------------------#
#          CAMBIOS DE ESTADO DE RUC Y CONDICION DE DOMICILIO          #
#---------------------------------------------------------------------#

SQL8<- paste0("select num_ruc, sum(indic)+1 cambios_condomic,sum(indic2) cambios_estado from (
              select a.num_ruc, a.ind_nohabido,b.ind_nohabido,a.x,b.y,c.z, a.fec_inivig, a.cod_estcontri ,b.cod_estcontri ,
              case when a.num_ruc||a.ind_nohabido<>a.num_ruc||b.ind_nohabido and c.z is null then 1 else 0 end indic ,
              case when a.num_ruc||a.cod_estcontri<>a.num_ruc||b.cod_estcontri and c.z is  null  then 1 else 0 end indic2 
              from 
              (Select num_ruc, ind_nohabido, fec_inivig, cod_estcontri,   
              RANK() OVER (ORDER BY num_ruc,fec_inivig asc) AS x
              from  informix.t2018padsunat 
              where num_ruc in ('",ruc_habilitados,"') order by num_ruc||fec_inivig) a
              left join 
              (Select num_ruc, ind_nohabido, fec_inivig,cod_estcontri,    
              RANK() OVER (ORDER BY num_ruc,fec_inivig asc) AS y
              from informix.t2018padsunat 
              where num_ruc in ('",ruc_habilitados,"') order by num_ruc||fec_inivig) b
              on a.x=(b.y-1)
              left join
              (select num_ruc,max(z)z from(
              Select num_ruc,RANK() OVER (ORDER BY num_ruc,fec_inivig asc) AS z
              from (select * from informix.t2018padsunat where num_ruc in ('",ruc_habilitados,"')))group by num_ruc) c
              on a.x=c.z
              order by a.x)
              group by num_ruc")
cambios<- sqlQuery(bdu, SQL8)
head(cambios)



#---------------------------------------------------------------------#
#                          CALIFICACI�N SBS                           #
#---------------------------------------------------------------------#

## Calificacion SBS
sbs <- sqlQuery(bdu, paste0(" select *, case
                            when calificacion =4 then 'PERDIDA'
                            when calificacion =3 then 'DUDOSO'
                            when calificacion =2 then 'DEFICIENTE'
                            when calificacion =1 then 'CPP'
                            else 'NORMAL' end calificacion_desc from (select a.ruc, max(a.calificacion) as calificacion from (
                            select num_docdeu as ruc, num_periodoinf as periodo, case
                            when por_Calif4 > 0 then 4
                            when por_Calif3 > 0 then 3
                            when por_Calif2 > 0 then 2
                            when por_Calif1 > 0 then 1
                            else 0 end calificacion
                            from vw_t2489regidcli
                            where num_periodoinf >= 201801 and num_periodoinf <= 201812 and num_docdeu in ('",ruc_habilitados,"')
                            ) a
                            group by a.ruc)
                            "))
head(sbs)


#---------------------------------------------------------------------#
#                            DEUDA COACTIVA                           #
#---------------------------------------------------------------------#

SQL9<- paste0("Select num_ruccv,
              sum(case when SUBSTR(cod_tipval,1,3)='001' OR cod_tipval in ('101000','111000') then 1 else 0 end) as OP,
              sum(case when SUBSTR(cod_tipval,1,3)='002' OR cod_tipval in ('112000','102000') then 1 else 0 end) as RM,
              sum(case when SUBSTR(cod_tipval,1,3)='003' OR  cod_tipval IN  ('113000','103000') then 1 else 0 end) as RD,
              
              sum(case when (SUBSTR(cod_tipval,1,3)='001' OR cod_tipval in ('101000','111000')) and ind_etabas='03'  then 1 else 0 end) as OP_COA,
              sum(case when (SUBSTR(cod_tipval,1,3)='002' OR cod_tipval in ('112000','102000')) and ind_etabas='03' then 1 else 0 end) as RM_COA,
              sum(case when (SUBSTR(cod_tipval,1,3)='003' OR  cod_tipval IN  ('113000','103000')) and ind_etabas='03' then 1 else 0 end) as RD_COA,
              
              sum(case when SUBSTR(cod_tipval,1,3)='001' OR cod_tipval in ('101000','111000') then mto_tri+mto_int+mto_intcap+mto_rec else 0 end) as OP_MONT,
              sum(case when SUBSTR(cod_tipval,1,3)='002' OR cod_tipval in ('112000','102000') then mto_tri+mto_int+mto_intcap+mto_rec else 0 end) as RM_MONT,
              sum(case when SUBSTR(cod_tipval,1,3)='003' OR  cod_tipval IN  ('113000','103000') then mto_tri+mto_int+mto_intcap+mto_rec else 0 end) as RD_MONT,
              
              sum(case when (SUBSTR(cod_tipval,1,3)='001' OR cod_tipval in ('101000','111000')) and ind_etabas='03'  then mto_tri+mto_int+mto_intcap+mto_rec else 0 end) as OP_MONT_COA,
              sum(case when (SUBSTR(cod_tipval,1,3)='002' OR cod_tipval in ('112000','102000')) and ind_etabas='03' then mto_tri+mto_int+mto_intcap+mto_rec  else 0 end) as RM_MONT_COA,
              sum(case when (SUBSTR(cod_tipval,1,3)='003' OR  cod_tipval IN  ('113000','103000')) and ind_etabas='03' then mto_tri+mto_int+mto_intcap+mto_rec  else 0 end) as RD_MONT_COA
              from informix.t2799valores
              where num_ruccv in ('",ruc_habilitados,"') and substr(per_emi,1,4)='2018'
              group by num_ruccv")
deuda<- sqlQuery(bdu, SQL9)
head(deuda)



#---------------------------------------------------------------------#
#                              PDT 621                                #
#---------------------------------------------------------------------#

#N�mero de rectificaciones y max de rectificaciones por mes
SQL10<- paste0("select a.ruc,a.rectificaciones,b.max_recti from 
               (Select num_docidenti as ruc, 
               SUM(to_number(C005))rectificaciones 
               from lzamudio.mod_piv_for_0621
               where substr(num_periodo,1,4)='2018'
               and num_docidenti in ('",ruc_habilitados,"')
               group by num_docidenti) a
               inner join
               (select ruc,max(rectificaciones)max_recti from (
               Select num_docidenti as ruc, 
               SUM(to_number(C005))rectificaciones,
               substr(num_periodo,5,2)mes
               from lzamudio.mod_piv_for_0621
               where substr(num_periodo,1,4)='2018' and num_docidenti in ('",ruc_habilitados,"')
               group by num_docidenti,mes
               )group by ruc) b
               on a.ruc=b.ruc")
rectificaciones<- sqlQuery(bda, SQL10)
head(rectificaciones)



# Ventas Internas , Ventas Externas , Compras internas , Compras Externas

#Para aquellos regimenes que declaran PDT 621
SQL11<- paste0("select num_docidenti,sum(c100+c105+c109+c112+c160)ventas_internas,
               sum(c106)ventas_externas,sum(c107+c110+c113+c120)compras_internas,
               sum(c114+c116+c119+c122)compras_externas,
               sum(c131)debito_fiscal,sum(c178)credito_fiscal,
               sum(c171)percepciones,sum(c179)retenciones,
               sum(c189)pago_igv,sum(c102)devoluciones
               from ( Select distinct a.cod_cic,num_docidenti,num_periodo,
               COALESCE(to_number(c100),0)c100,
               COALESCE(to_number(c105),0)c105,
               COALESCE(to_number(c109),0)c109,
               COALESCE(to_number(c112),0)c112,
               COALESCE(to_number(c160),0)c160,
               COALESCE(to_number(c106),0)c106,
               COALESCE(to_number(c107),0)c107,
               COALESCE(to_number(c110),0)c110,
               COALESCE(to_number(c113),0)c113,
               COALESCE(to_number(c120),0)c120,
               COALESCE(to_number(c114),0)c114,
               COALESCE(to_number(c116),0)c116,
               COALESCE(to_number(c119),0)c119,
               COALESCE(to_number(c122),0)c122, 
               COALESCE(to_number(c131),0)c131,
               COALESCE(to_number(c178),0)c178,
               COALESCE(to_number(c171),0)c171,
               COALESCE(to_number(c179),0)c179,
               COALESCE(to_number(c189),0)c189,
               COALESCE(to_number(c102),0)c102
               from lzamudio.mod_piv_for_0621 a
               inner join (select * from lzamudio.vw_cab_unicas where cod_formul='0621') b 
               on (a.num_nabono=b.num_nabono and a.num_orden=b.num_orden and a.cod_cic=b.cod_cic and trim(a.num_periodo)=trim(b.per_tributo))
               where substr(num_periodo,1,4)='2018' and cod_tributo = '010101' and num_docidenti  in ('",ruc_habilitados,"')) group by num_docidenti ") 
pdt621<- sqlQuery(bda, SQL11)
head(pdt621)

#Nota: hasta el momento del an�lisis no se apreci�n alg�n RUC asociado al regimen de 4ta cat o RUS



#---------------------------------------------------------------------#
#                                ITF                                  #
#---------------------------------------------------------------------#


SQL12<- paste0("SELECT  n_dcto_declado as ruc,cod_operacion,
               case when mto_base is null then (mto_impuesto/0.00005) else mto_base end mto_base
               FROM informix.vw_itf_det2018
               WHERE  n_dcto_declado in ('",ruc_habilitados,"') ")
itf<- sqlQuery(bdu, SQL12)
head(itf)


itf_final<-sqldf("select ruc ,COALESCE(ingreso_itf, 0)ingreso,COALESCE(egreso_itf, 0)egreso ,COALESCE(itf_mov, 0)itf_mov  from (select ruc, case when cod_operacion in ('4','12','13','20','21') then sum (COALESCE(mto_base, 0)) end as ingreso_itf,
                 case when cod_operacion in ('2','8','9','14','15','16','17','18','19') then sum( COALESCE(mto_base, 0)) end as egreso_itf,
                 case when cod_operacion in ('2','8','9','14','15','16','17','18','19','4','12','13','20','21') then sum( COALESCE(mto_base, 0)) end as itf_mov
                 from itf group by ruc)")
head(itf_final)



#Movimientos ITF de los Despachadores y Auxiliares 
SQL12<- paste0("SELECT  n_dcto_declado as doc,cod_operacion,
               case when mto_base is null then (mto_impuesto/0.00005) else mto_base end mto_base
               FROM informix.vw_itf_det2018
               WHERE  n_dcto_declado in ('",doclegales_desp_aux,"') ")
itf_despachadores<- sqlQuery(bdu, SQL12)
head(itf_despachadores)



itf_despachadores_final<-sqldf("select doc ,COALESCE(ingreso_itf, 0)ingreso_itf,COALESCE(egreso_itf, 0)egreso_itf, COALESCE(itf_mov, 0)itf_mov
                               from (select doc, case when cod_operacion in ('4','12','13','20','21') then sum (COALESCE(mto_base, 0)) end as ingreso_itf,
                               case when cod_operacion in ('2','8','9','14','15','16','17','18','19') then sum( COALESCE(mto_base, 0)) end as egreso_itf,
                               case when cod_operacion in ('2','8','9','14','15','16','17','18','19','4','12','13','20','21') then sum( COALESCE(mto_base, 0)) end as itf_mov
                               from itf_despachadores group by doc)")
itf_despachadores_final$doc<-str_pad(itf_despachadores_final$doc, 8, pad = "0")
head(itf_despachadores_final)


itf_despachores_final2<-sqldf("select a.cdocumento,sum(ingreso_itf)ingreso_itf_aux,sum(egreso_itf)egreso_itf_aux,sum(itf_mov)itf_mov_aux
                              from desp_aux a
                              inner join itf_despachadores_final b on a.ndocumen=b.doc 
                              group by a.cdocumento")
head(itf_despachores_final2)


#---------------------------------------------------------------------#
#                   MONTOS PERCIBIDOS 4TA + 5TA                       #
#---------------------------------------------------------------------#


#Montos Percibidos de 4ta y 5ta Categoria 
SQL12<- paste0("select num_docdec,sum(mto_percib) monto_percib from (
               select num_docdec,num_docqui,sum(mto_birtaqui)mto_percib from informix.t2534rtaquihis
               WHERE  num_docqui in ('",doclegales_desp_aux,"') and num_novedad='38' and substr(per_trib,1,4)='2018' group by num_docdec,num_docqui
               union all
               select num_docdec,dni,sum(mto_percib)mto_percib from (
               Select num_docdec, substr(num_docind,3,8)dni, mto_percib  from informix.t2530cdp621his
               where substr(per_trib,1,4)='2018' and num_novedad='38' and substr(num_docind,3,8) in ('",doclegales_desp_aux,"')) group by num_docdec, dni
)group by num_docdec")
pago_despachadores<- sqlQuery(bdu, SQL12)


SQL5<- paste0("Select num_ruc,  num_doccli,  sum(mto_percib)mto_percib from lzamudio.t5922reciboseehis
              where substr(per_trib,1,4)='2018' and substr(num_ruc,3,8) in ('",doclegales_desp_aux,"')
              group by num_ruc,  num_doccli")
monto_recibos_honorarios<- sqlQuery(bda, SQL5)


pago_despachadores_final<-sqldf("select num_docdec ,sum(monto_percib)monto_percib from 
                                (select num_docdec,monto_percib from pago_despachadores union select num_ruc,mto_percib 
                                from monto_recibos_honorarios)group by num_docdec")
head(pago_despachadores_final)


#Nota: ya que se evalu� un periodo anterior se usaron las tablas histporicas, en caso de realice de periodos actuales , se debe modificar
#las tablas
write.xlsx(pago_despachadores_final, 'pago_despachadores_final.xlsx')




#---------------------------------------------------------------------#
#                     ORDENES DE FISCALIZACI�N                        #
#---------------------------------------------------------------------#

SQL13<- paste0("Select num_docfis,count(*)of from informix.t2086of
               where num_docfis in ('",ruc_habilitados,"')
               group by num_docfis")
orden_fiscal<- sqlQuery(bdu, SQL13)
head(orden_fiscal)


#---------------------------------------------------------------------#
#                         DATOS DE FICHA RUC                          #
#---------------------------------------------------------------------#

SQL<- paste0("select * from (Select ruc,trim(razon_social)razon_social,dependencia,condicion,estado,tipo_emp,act_principal,
             fec_ins,fec_ini_act,fec_baj,ubigeo,desc_ubigeo
             from lzamudio.mod_ficha_nacional) where ruc in ('",ruc_habilitados,"')")
padsunat<- sqlQuery(bda, SQL)
head(padsunat)


#Tabla vw_padsunat (a�adiendo la fecha de inscripci�n hist�rica )
SQL <- paste0("SELECT distinct t273_numruc as ruc,min(t273_fecalt) as fecha_hist  FROM lzamudio.t273hddp a 
               WHERE t273_numruc IN ('",ruc_habilitados,"') group by t273_numruc")
t273hddp<- sqlQuery(bda2, SQL)
head(t273hddp)


ficha_ruc<- sqldf("SELECT a.*,b.fecha_hist from padsunat a left join t273hddp b on a.ruc=b.ruc")
ficha_ruc$fecha_inscr_real <-sapply(apply(ficha_ruc[c(8,13)],1,na.exclude),min)
ficha_ruc$antiguedad <-ifelse(ficha_ruc$fec_baj=="0001-01-01" ,(as.Date("2019-08-13")- as.Date(ficha_ruc$fecha_inscr_real))/365, (ficha_ruc$fec_baj-ficha_ruc$fecha_inscr_real)/365)

ficha_ruc$ubigeo<-str_pad(ficha_ruc$ubigeo, 6, pad = "0")
ficha_ruc$dependencia<-str_pad(ficha_ruc$dependencia, 3, pad = "0")
head(ficha_ruc,20)



#Tabla para a�adir el tiempo de actividad
SQL<- paste0("select a.*,b.estado_act,b.fech_iniv,today as fech_act, 
                          case when b.estado_act=00 then (today- a.fec_ins-dias_inactividad)/365  else (b.fech_iniv-1-b.fec_ins-dias_inactividad)/365 end tiempo_act_anos from 
                          (
                          select num_ruc,min(fec_ins)fec_ins,sum(dias)dias_inactividad from (
                          select x.*,case when cod_estcontri<>00 then fec_finvig-fec_inivig else 0 end  dias from (
                          Select num_ruc,  cod_estcontri, 
                          case when fec_inivig=date('01/01/1900') then fec_ins else fec_inivig end fec_inivig,
                          fec_finvig,  ind_datactual,  fec_ins,  fec_baja
                          from informix.t2018padsunat
                          where num_ruc in ('",ruc_habilitados,"') and ind_datactual<>'1'
                          )x
                          )group by num_ruc
                          )a
                          inner join (Select num_ruc,  cod_estcontri estado_act, fec_inivig as fech_iniv, fec_finvig as fech_finvig,  ind_datactual,  fec_ins,  fec_baja
                          from informix.t2018padsunat
                          where num_ruc in ('",ruc_habilitados,"') and ind_datactual='1') b on a.num_ruc=b.num_ruc
                          ")
tiempo_actividad<- sqlQuery(bdu, SQL)
head(tiempo_actividad)

# subset(tiempo_actividad,tiempo_actividad$num_ruc=='20513646861')
# subset(ficha_ruc,ficha_ruc$ruc=='20513646861')
#---------------------------------------------------------------------#
#                            VINCULACIONES                            #
#---------------------------------------------------------------------#

representantes<-sqldf("select a.*,b.estado_agente from matriz_representantes a left join agentes b on a.ruc=b.cdocumento where doc_repre not in ('99999999','00000000')")
vinculaciones<- sqldf(" select ruc, count(distinct doc_repre) nro_doc_vinc ,count(distinct ruc_inh )ruc_inhabilitados
                      from (select a.*,c.ruc as ruc_inh from  
                      (select * from representantes where estado_agente='HABILITADO') a   
                      inner join (select doc_repre,ruc from representantes where estado_agente<>'HABILITADO' ) c
                      on a.doc_repre=c.doc_repre)
                      group by ruc")
head(vinculaciones)

representantes1<-sqldf("select doc_repre,count(ruc)ruc,estado_agente from representantes group by doc_repre,estado_agente")
temp1<-reshape(aggregate(ruc~doc_repre+ESTADO_AGENTE,representantes1,max),direction = "wide", idvar = c("doc_repre"), timevar = "ESTADO_AGENTE")
head(temp1)
temp1$total_empr<-rowSums (temp1[,2:4],na.rm=T)
temp1$ruc_malos<-rowSums (temp1[c(2,4)],na.rm=T)
temp1$ind<-temp1$ruc_malos/temp1$total_empr
temp2<-merge(representantes,temp1,by='doc_repre')
head(temp2)
write.xlsx(temp2, 'doc_vinculaciones.xlsx')

vinculaciones1<-sqldf("select ruc,ind/nro_representantes as ind_vinculaciones from (select ruc, sum(ind)ind,count(ruc)nro_representantes from temp2
                      where estado_agente='HABILITADO' 
                      group by ruc )")
head(vinculaciones1)
#subset(vinculaciones2,vinculaciones2$ruc=='20463958590')



#---------------------------------------------------------------------#
#                         TABLA FINAL TRIBUTOS                        #
#---------------------------------------------------------------------#

#,m.nombre,m.tipoempr,m.tamano,m.ciiu,m.antiguedad,m.ubigeo,d.REGIMEN_nro,
#left join vw_ddp m on a.cdocumento=m.ruc



matriz_final1<-sqldf("select a.ruc, a.razon_social,a.dependencia, a.condicion,a.estado,c.regimen,a.tipo_emp,a.act_principal,a.fecha_inscr_real,
                     a.ubigeo,a.desc_ubigeo,d.calificacion_desc as calificacion_sbs,a.antiguedad,b.tiempo_act_anos,
                     e.cambios_condomic,e.cambios_estado,'VINCULACIONES' as VINCULACIONES,f.nro_doc_vinc,f.ruc_inhabilitados,g.ind_vinculaciones
                     from ficha_ruc a
                     left join tiempo_actividad b on a.ruc=b.num_ruc
                     left join regimen_tributario c on a.ruc=c.ruc
                     left join sbs d on a.ruc=d.ruc
                     left join cambios e on a.ruc=e.num_ruc
                     left join vinculaciones f on a.ruc=f.ruc
                     left join vinculaciones1 g on a.ruc=g.ruc")
head(matriz_final1)

#-------------------------

matriz_final2<-sqldf("select distinct a.*,b.pensionistas,b.practicantes,b.prest_terceros,b.cuarta_cat,b.monto_4ta,b.quinta_cat,b.monto_5ta,'DATOS_AUXILIARES' as DATOS_AUXILIARES,c.auxiliares,
                      d.monto_percib as pago_auxiliares,
                    c.nroviajes_desp_aux,e.ingreso_itf_aux,e.egreso_itf_aux,e.itf_mov_aux
                     from matriz_final1 a
                     left join  trabajadores b on a.ruc=b.num_docidenti
                     left join migraciones c on a.ruc=c.cdocumento
                     left join pago_despachadores_final d on a.ruc=d.num_docdec
                     left join itf_despachores_final2 e on a.ruc=e.cdocumento")
head(matriz_final2)


#-------------------------


matriz_final_tributos<-sqldf("select a.*,'DATOS_PDT' as PDT ,b.rectificaciones,d.ventas_internas,d.ventas_externas,d.compras_internas,d.compras_externas,
                    d.debito_fiscal,d.credito_fiscal,d.percepciones,d.retenciones,d.pago_igv,d.devoluciones,'DATOS_ITF' as DATOS_ITF,
                    e.ingreso as ingreso_itf, e.egreso as egreso_itf,e.itf_mov,'ORDENES_TRIBUTOS' as ORDENES_TRIBUTOS,
                    c.of as ordenes_fiscales,op as ordenes_pago, rm as resol_multa, rd as resol_deter,op_coa,rm_coa,rd_coa,op_mont,rm_mont,rd_mont,
                    op_mont_coa,rm_mont_coa,rd_mont_coa
                    from matriz_final2 a
                    left join rectificaciones b on a.ruc=b.ruc
                    left join orden_fiscal c on a.ruc=c.num_docfis
                    left join pdt621 d on a.ruc=d.num_docidenti
                    left join itf_final e on a.ruc=e.ruc
                    left join deuda f on a.ruc=f.num_ruccv")
head(matriz_final_tributos)
write.xlsx(matriz_final_tributos, 'matriz_final_tributos.xlsx')

#-------------------------




#-------------------------------------------------------------------------------------#
#                               TABLA FINAL DE ADUANAS                                #
#-------------------------------------------------------------------------------------#

#Datos de Agente de Aduanas - OEA
oea<- sqlQuery(prad1, "Select DISTINCT CDOCUMENTO,CODN_CAMPO from Operador_comex 
                      Where CODN_CAMPO='OPER_ECON_AUT' AND FFIN_VIGEN ='99991231'
                      AND CODV_CAMPO ='2' ")
#visualizar los datos
head(oea)



## Data proporcionado por la Divisi�n de Gesti�n de Riesgos (Sr. Cristian Cuellar)
matriz_aduanas<-read.xlsx("matriz_aduanas.xlsx")
head(matriz_aduanas,3)
str(matriz_aduanas)





#-------------------------------------------------------------------------------------#
#                           MATRIZ FINAL TRIBUTOS + ADUANAS                           #
#-------------------------------------------------------------------------------------#

matriz<- merge(matriz_final_tributos,matriz_aduanas,  by="ruc", all.x =TRUE)
head(matriz)


matriz_final<-sqldf("select cagente,case when a.ruc=b.cdocumento then '1' else '0' end oea,a.*
                    from matriz a left join oea b on a.ruc=b.cdocumento
                    left join (select distinct cagente,cdocumento from  agentes) c on a.ruc=c.cdocumento")
head(matriz_final)
matriz_final$antiguedad<-as.integer(floor(matriz_final$antiguedad))
matriz_final$tiempo_act_anos<-as.integer(floor(matriz_final$tiempo_act_anos))

#Exportaci�n de datos
write.xlsx(matriz_final, 'matriz_final_agentes.xlsx')


head(matriz_final)



#---------------------------------------------------------------------#
#                           CERRAR CONECCIONES                        #
#---------------------------------------------------------------------#

#Cerrar conecciones totales
odbcCloseAll()














#-------------------------------------------------------------------------------------#
#                   ANALISIS EXPLORATORIO - DISTRIBUCI�N DE INDICADORES
#-------------------------------------------------------------------------------------#


boxplot (matriz_final$ind_cuarta_quinta,notch=TRUE,col=(c("blue4")))
summary(matriz_final$ind_cuarta_quinta)

boxplot (matriz_final$ind_aux_viajes,notch=TRUE,col=(c("blue4")))
summary(matriz_final$ind_aux_viajes)

boxplot (matriz_final$rectificaciones,col=(c("blue4")))
summary(matriz_final$rectificaciones)

boxplot (matriz_final$ind_cambios_antiguedad,col=(c("blue4")))
summary(matriz_final$ind_cambios_antiguedad)

boxplot (matriz_final$ind_ventas_compras,col=(c("blue4")))
summary(matriz_final$ind_ventas_compras)

boxplot (matriz_final$nro_doc,col=(c("blue4")))
summary(matriz_final$nro_doc)

boxplot (matriz_final$cant_ruc_inhabilitados,col=(c("blue4")))
summary(matriz_final$cant_ruc_inhabilitados)

boxplot (matriz_final$monto_inci,col=(c("blue4")))
summary(matriz_final$monto_inci)

boxplot (matriz_final$ind_dam_r_n_total_dam_r_n,col=(c("blue4")))
summary(matriz_final$ind_dam_r_n_total_dam_r_n)

boxplot (matriz_final$ind_op_rm_rd_of,col=(c("blue4")))
summary(matriz_final$ind_op_rm_rd_of)

boxplot (matriz_final$ind_itf_ventas_compras,col=(c("blue4")))
summary(matriz_final$ind_itf_ventas_compras)

boxplot (matriz_final$inci_programas,col=(c("blue4")))
summary(matriz_final$inci_programas)

boxplot (matriz_final$actas_delito_multa,col=(c("blue4")))
summary(matriz_final$actas_delito_multa)

boxplot (matriz_final$ind_itf_despa_monto_pago,col=(c("blue4")))
summary(matriz_final$ind_itf_despa_monto_pago)



#-------------------------------------------------------------------------------------#
#                             TRANSFORMACIONES DE VARIABLES
#-------------------------------------------------------------------------------------#


#Indicador de Suma de (Cambios de Estado + Condiciones de Domicilio) / Antiguedad
x<-log(matriz_tributos$ind_cambios_antiguedad)
hist(x,prob=TRUE,las=1,main='cambios/antiguedad')
lines(density(x), col="blue", lty=2, lwd=3)  

#Indicador de Monto de Cuarta/Monto de Quinta
x<-(matriz_tributos$ind_cuarta_quinta)^ (1/3)
hist(x,prob=TRUE,las=1,main='cuarta/quinta')
lines(density(x), col="blue", lty=2, lwd=3)  


# Indicador de Monto de Ventas (Internas y Externas) Totales / Compras (Internas y Externas) Totales
x<-log(matriz_tributos$ind_ventas_compras+1)
x <- replace(x,is.na(x),0)
hist(x,prob=TRUE,las=1,main='Ventas/Compras')
lines(density(x), col="blue", lty=2, lwd=3)  


#Indicador de Dam con Incidencia R Y N/ Total de DAM's R y N
x<-(matriz_final$ind_dam_r_n_total_dam_r_n)^ (1/2)
hist(x,prob=TRUE,las=1,main='Inci R y M / DAM total R y M')
lines(density(x), col="blue", lty=2, lwd=3)  


#Monto de Incidencia
x<-log(matriz_final$monto_inci+1)
#x <- replace(x,is.na(x),0)
hist(x,prob=TRUE,las=1,main='Monto Incidencia')
lines(density(x), col="blue", lty=2, lwd=3)  



#Monto de ITF /(VENTAS+COMPRAS)
x<-log(matriz_final$ind_itf_ventas_compras+1)
#x <- replace(x,is.na(x),0)
hist(x,prob=TRUE,las=1,main='ITF/(Ventas y compras')
lines(density(x), col="blue", lty=2, lwd=3)  


#Indicador de ind_op_rm_rd_of
x<-log((matriz_final$ind_op_rm_rd_of)^ (1/3)+1)
#x <- replace(x,is.na(x),0)
hist(x,prob=TRUE,las=1,main='IND OP' )
lines(density(x), col="blue", lty=2, lwd=3)  


#Indicadores de Viajes/ n�mero de auxiliares de despacho
x<-log((matriz_final$ind_aux_viajes)^ (1/2)+1)
#x <- replace(x,is.na(x),0)
hist(x,prob=TRUE,las=1,main='Viajes/Auxiliares')
lines(density(x), col="blue", lty=2, lwd=3)  





#-------------------------------------------------------------------------------------#
#                                           FIN
#-------------------------------------------------------------------------------------#

























